package Test;

public class test1 {

    public static void getString(){
        System.out.println("Update System");
        System.out.println("Update System");
        System.out.println("Update System");
        System.out.println("Bug nut");
    }

    public static void main(String[] args) {

    }

}
